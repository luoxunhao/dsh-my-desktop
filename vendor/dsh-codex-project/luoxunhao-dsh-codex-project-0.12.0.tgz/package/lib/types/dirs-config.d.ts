/**
 * dsh-codex-project configuration access: the additional-writable-dir model.
 * One workspace owns a record `{ path, dirs }` — `path` is the canonical main
 * workspace directory (the matching anchor the runner also uses), `dirs` are
 * the additional writable directories the workspace's sessions may read/write.
 * The record set is the plugin's ONLY persisted state; sessions whose cwd is
 * outside every record, or whose owning record has no dirs, keep the core
 * single-workspace behavior.
 *
 * Records live in a SQLite database at `$DSH_CODEX_PROJECT_CONFIG` when set,
 * else `~/.dsh-codex-project/dirs.db`. SQLite commits a config update in one
 * transactional write — it never depends on the temp-file + rename swap that
 * Windows can fail with EPERM when the target is briefly locked. A single
 * `workspaces` table holds one row per record; `dirs` is stored as JSON text
 * in `dirs_json`.
 *
 * The driver is Node's built-in `node:sqlite` (`DatabaseSync`): no native
 * module to install or rebuild, so it loads identically in the host, the fs
 * provider, and the confinement runner regardless of the DSH runtime's Node /
 * Electron ABI. This module owns the connection (dirs-store.ts writes through
 * the same one) and the pure matching helpers. The pure helpers
 * (`matchingWorkspace`, `requireCanonicalDirectory`) carry no storage so the
 * fs/runner bundles that import them stay decoupled from the handle mechanics.
 * An absent database means "no records" — the plugin stays a pure pass-through.
 *
 * Matching: a session cwd (canonical) that equals a record's `path` owns that
 * record; the writable root set is `[path, ...surviving dirs]`. A configured
 * dir that vanished narrows the set (a dead directory is physically
 * unwritable), never throwing and never poisoning unrelated sessions or
 * records.
 * @module dsh-codex-project/dirs-config
 */
/** One workspace's persisted record: main path + additional writable dirs. */
export interface WorkspaceDirs {
    /** Canonical main workspace directory (the runner's matching anchor). */
    path: string;
    /** Additional writable directories (absolute, may cross drives). */
    dirs: string[];
}
/** A resolved match: the owning workspace + its writable root split. */
export interface WorkspaceMatch {
    workspaceId: string;
    /** Canonical surviving writable roots: path + existing dirs. */
    roots: string[];
    /** Configured dirs that no longer exist (skipped, never failing). */
    missingDirs: string[];
}
/** The default data file location (`~/.dsh-codex-project/dirs.db`). */
export declare const DEFAULT_DIRS_CONFIG_PATH: string;
/** The data file path: `$DSH_CODEX_PROJECT_CONFIG`, else the default. */
export declare function dirsConfigPath(): string;
/** Close the open handle (idempotent). Tests call this before removing a DB. */
export declare function closeDirsDb(): void;
/** Whether the resolved DB path currently has an open handle. */
export declare function isDirsDbOpen(): boolean;
/**
 * Load the configured workspace dirs from the SQLite store. A missing file
 * means none; a row whose `path`/`dirs_json` is not the documented shape is a
 * configuration error and throws.
 * @returns the configured records (possibly empty).
 */
export declare function loadWorkspaceDirs(): Record<string, WorkspaceDirs>;
/**
 * Replace the whole record set in one transaction. This is the ONLY write
 * primitive the store uses; a single transaction means the set is never
 * observed half-updated, and it needs no temp file + rename (the Windows-EPERM
 * trap the JSON loader fell into).
 * @param records - the full record map to persist.
 */
export declare function writeWorkspaceDirs(records: Record<string, WorkspaceDirs>): void;
/**
 * Canonicalize one directory, failing loud when it does not exist.
 * @param label - what the directory is, for the error.
 * @param path - the directory to canonicalize.
 * @returns the canonical path (Windows: the `\\?\` real path).
 */
export declare function requireCanonicalDirectory(label: string, path: string): string;
/**
 * Canonicalize one directory without failing: a missing or non-directory path
 * yields `undefined`. A dir that vanished after being configured must never
 * throw — it narrows the writable set instead of failing every match.
 * @param path - the directory to canonicalize.
 * @returns the canonical path, or `undefined` when the path is not a directory.
 */
export declare function tryCanonicalDirectory(path: string): string | undefined;
/**
 * The workspace record whose canonical `path` equals the canonical session
 * workspace, if any.
 * @param records - the loaded records.
 * @param canonicalWorkspace - the canonical session cwd.
 * @returns the owner id, or undefined when no record anchors this workspace.
 */
export declare function matchingWorkspace(records: Record<string, WorkspaceDirs>, canonicalWorkspace: string): WorkspaceMatch | undefined;
/**
 * The canonical directory holding the data file. Exists by the store's
 * guarantee once any record is configured (the store creates the parent);
 * the runner derives the workspace SID from it — see `space-sid.ts`.
 */
export declare function dirsConfigDirectory(): string;
