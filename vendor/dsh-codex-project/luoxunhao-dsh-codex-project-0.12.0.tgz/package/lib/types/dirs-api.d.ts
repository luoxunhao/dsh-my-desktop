/**
 * The /codex-project/api JSON route logic as a pure function over the store
 * — the HTTP adapter in `src/index.ts` only parses the request and calls
 * `handle`, so the whole surface is testable without a server.
 *
 * Routes:
 *  - GET    /codex-project/api/ping        → mount smoke
 *  - GET    /codex-project/api/dirs        → one workspace's additional dirs
 *                                            (?workspaceId=<id>) — a workspace
 *                                            with NO recorded dirs returns an
 *                                            empty list (never 404: any
 *                                            registry workspace can manage its
 *                                            additional dirs)
 *  - PUT    /codex-project/api/dirs        → replace one workspace's dirs
 *                                            ({ workspaceId, dirs }); the
 *                                            workspace is anchored first so a
 *                                            first-time addition creates its
 *                                            record
 *  - GET    /codex-project/api/project     → the project anchored at a cwd
 *                                            (?cwd=<path>) — { path, dirs,
 *                                            missingDirs } or null
 *  - GET    /codex-project/api/list        → one project-root directory level
 *                                            (?cwd=<path>&path=<abs>), fenced
 *                                            to the project's roots
 *  - GET    /codex-project/api/read        → one text file's content
 *                                            (?cwd=<path>&path=<abs>), fenced;
 *                                            capped at READ_CAP bytes with a
 *                                            `truncated` flag
 *  - POST   /codex-project/api/write       → save a text file
 *                                            ({ cwd, path, content }), fenced
 *  - GET    /codex-project/api/file        → raw file bytes
 *                                            (?cwd=<path>&path=<abs>[&download=1]),
 *                                            fenced; download sets an
 *                                            attachment disposition
 *  - POST   /codex-project/api/open-directory → native-open a folder (kept)
 *  - GET    /codex-project/api/pick-roots     → the in-page picker's navigable
 *                                              roots (drive letters / home)
 *  - GET    /codex-project/api/pick-list      → one arbitrary absolute directory's
 *                                              subdirectories + parent (in-page
 *                                              picker; UNFENCED — lets the user
 *                                              grant any folder, like the native
 *                                              picker, but read-only listings)
 *  - GET    /codex-project/api/search         → recursive file-name search over the
 *                                              project roots
 *                                              (?cwd=<path>&query=<name>), fenced
 *  - POST   /codex-project/api/upload         → write uploaded files under the
 *                                              project roots
 *                                              ({ cwd, dir, files: [{ path, contentBase64 }] }),
 *                                              fenced (bounded file count + total bytes)
 *
 * Errors: 400 for invalid input (bad shape, missing dir, unknown workspace
 * cannot be resolved from the registry), 403 for a path outside a project's
 * roots, 404 for an unknown workspace, 405 for unknown routes/methods.
 * @module dsh-codex-project/dirs-api
 */
import type { DirsStore, WorkspaceRegistryFace } from './dirs-store.ts';
/**
 * One API response: HTTP status plus a JSON body, optionally a raw byte
 * payload (the /file route) with its content type and extra headers.
 */
export interface ApiResponse {
    status: number;
    body: unknown;
    raw?: Buffer;
    contentType?: string;
    headers?: Record<string, string>;
}
/** Text reads are capped so a giant file cannot pin the GUI or the bridge. */
export declare const READ_CAP: number;
/** Read a text file up to READ_CAP bytes; longer files flag `truncated`. */
export declare function readProjectFile(path: string, maxBytes?: number): Promise<{
    content: string;
    truncated: boolean;
}>;
/** Read a raw file, fenced to a project's roots, as a byte response. */
export declare function readProjectFileRaw(path: string, download?: boolean): Promise<{
    raw: Buffer;
    contentType: string;
    headers: Record<string, string>;
}>;
/**
 * Dispatch one request.
 * @param store - the persisted store.
 * @param registry - the host workspace registry (path resolution for anchoring).
 * @param method - the HTTP method (uppercased).
 * @param pathname - the request path INCLUDING any query
 *   (`/codex-project/api/dirs?workspaceId=<id>`).
 * @param body - the parsed JSON body (PUT).
 * @returns the response.
 */
export declare function dirsApi(store: DirsStore, registry: WorkspaceRegistryFace, method: string, pathname: string, body: unknown): Promise<ApiResponse>;
