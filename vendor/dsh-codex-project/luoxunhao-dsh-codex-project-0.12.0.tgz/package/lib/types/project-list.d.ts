/**
 * Project folder listing for the 项目文件夹 tab: a self-contained directory
 * listing (opendir stream, dirs-first + case-insensitive name sort, symlink
 * target probing) plus a fence that only admits paths inside a project's
 * roots. Kept local to the plugin — the tab renders its own tree, so it owns
 * its listing feed too (mirrors the better-sidebar fs-tree shape so the wire
 * is familiar, without importing that plugin's runtime symbols).
 * @module dsh-codex-project/project-list
 */
/** One project-tree row. */
export interface ProjectEntry {
    name: string;
    path: string;
    isDir: boolean;
    hidden: boolean;
    /** Whether the row is a symlink; `isDir` then describes the link's target. */
    isSymlink: boolean;
    /** For symlinks: the target is missing or unreadable (stat failed). */
    broken: boolean;
}
/** One listed directory level. */
export interface ProjectListing {
    path: string;
    entries: ProjectEntry[];
    truncated: boolean;
}
/** Directory-first, case-insensitive name ordering (VSCode explorer order). */
export declare function compareEntries(a: ProjectEntry, b: ProjectEntry): number;
/**
 * List one directory level.
 * @param path - absolute directory path.
 * @param maxEntries - row bound of one level (extra rows flag `truncated`).
 * @returns the sorted listing.
 * @throws when the level is unreadable or not a directory.
 */
export declare function listProjectDirectory(path: string, maxEntries?: number): Promise<ProjectListing>;
/**
 * Whether a target path lies inside any of a project's roots (main root +
 * surviving shared dirs). Uses the plugin's containment semantics, so a
 * Windows alias/case spelling still fences correctly.
 * @param target - the absolute path to test.
 * @param roots - the project's writable roots.
 * @returns whether the target is a root or a descendant of one.
 */
export declare function isWithinRoots(target: string, roots: readonly string[]): Promise<boolean>;
