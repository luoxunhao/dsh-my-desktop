/**
 * 页内目录选择（folder picker）host feed — an UNFENCED directory browser for
 * the manage dialog's 添加附加目录 picker. Unlike the fenced project `/list`
 * route, this feed must navigate the whole filesystem so the user can grant
 * write access to any folder (mirroring the OS FolderBrowserDialog's reach).
 *
 * Security boundary: the whole `/codex-project/api` prefix is loopback-guarded
 * in `src/index.ts`, and this feed is READ-ONLY — it only returns directory
 * names and ancestry for navigation, never file contents. It exists solely to
 * let the user point the add-dir action at an arbitrary local folder, the same
 * trust the native picker already grants.
 *
 * Path input on Windows accepts BOTH native forms (`C:\`, `C:/Users/...`) and
 * Git-Bash / MSYS Linux-style roots (`/c`, `/d`, `/c/Users/...`) via
 * {@link normalizePickPath}, so a Win10 user can type `/c` or `/d` to jump to a
 * drive root.
 *
 * Two operations:
 *  - roots: the navigable top level — drive letters on Windows, `/` elsewhere
 *    (plus the OS home for a convenient anchor).
 *  - list: one directory's subdirectories plus its parent path, accepting any
 *    of the normalized input forms.
 * @module dsh-codex-project/pick-browse
 */
/** One browsable directory entry (subdirectory or root). */
export interface PickEntry {
    name: string;
    path: string;
}
/** The navigable root set: every present drive letter + the OS home. */
export declare function pickRoots(): PickEntry[];
/**
 * Normalize a user-typed path to an absolute Windows path (on win32) or pass
 * through an absolute posix path elsewhere.
 *
 * Accepted forms on Windows (case-insensitive drive letter):
 *  - Git-Bash / MSYS Linux-style: `/c`, `/c/Users/foo`, `/d` → `C:\`, `C:\Users\foo`, `D:\`
 *  - native drive forms: `C:\`, `C:/Users/foo`, `c:/foo`, `c:`
 *
 * Returns the normalized absolute path, or `undefined` when the input is not a
 * recognizable absolute path for this platform.
 * @param input - the raw path the user typed.
 * @param platform - the target platform (defaults to the host's), injectable
 *   so the win32 Git-Bash mapping is testable on any platform.
 * @returns the normalized absolute path, or undefined.
 */
export declare function normalizePickPath(input: string, platform?: NodeJS.Platform): string | undefined;
/** One directory level: the current dir, its parent, and its subdirectories. */
export interface PickLevel {
    path: string;
    /** The absolute parent directory, or null when `path` is a top level. */
    parent: string | null;
    /** Direct subdirectories (dirs-first, case-insensitive order). */
    dirs: PickEntry[];
    /** The OS home (an anchor the client can jump to). */
    home: string;
}
/**
 * List one directory level for the picker, accepting any of the input forms
 * {@link normalizePickPath} understands (`/c`, `/c/Users/foo`, `C:\`, ...).
 * @param path - a directory path to browse (native or Git-Bash style).
 * @returns the level's subdirectories, parent, and home anchor.
 * @throws when the path is not an absolute existing directory.
 */
export declare function pickLevel(path: string): Promise<PickLevel>;
/** Whether `path` is a Windows drive root ("C:\") or the posix root ("/"). */
export declare function isDriveRoot(path: string): boolean;
