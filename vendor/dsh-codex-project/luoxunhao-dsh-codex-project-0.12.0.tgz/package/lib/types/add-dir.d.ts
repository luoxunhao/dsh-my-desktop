/**
 * The `add_dir` model tool: the Claude Code `/add-dir` equivalent inside
 * dsh. The model requests a directory; the user confirms through the dsh
 * approval seam (`ctx.approval.request` — the dialog and audit are core
 * capabilities, the plugin only asks); on `'allowed-once'` the directory is
 * added to the ADDITIONAL writable dirs of the calling session's workspace
 * and persisted. It is a root addition only — no file reads, no command
 * execution; everything beyond the write is the model's own work.
 *
 * Name note: the model tool is `add_dir` (underscore), matching dsh's
 * model-tool naming convention (model tools use underscores, e.g.
 * `ask_user_question`, `todo_write`); the parallel human command is
 * `/adddir`.
 * @module dsh-codex-project/add-dir
 */
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { ApprovalOutcome } from '@deepseek-ai/dsh-user-approval';
import type { DirsStore } from './dirs-store.ts';
/** Structural mirror of the plugin deps the tool needs (wired in index.ts). */
export interface AddDirToolDeps {
    /** Resolve the owning workspace id of a session cwd. */
    resolveWorkspaceId(cwd: string): string | undefined;
    /** Ask the user to confirm via the dsh approval seam. */
    requestApproval(agent: Agent, path: string, signal: AbortSignal): Promise<ApprovalOutcome>;
    /** Persist the added directory. */
    store: DirsStore;
}
/** Wire-safe result of one add-dir call. */
export interface AddDirResult {
    ok: boolean;
    /** The updated additional-dir list on success; absent on failure. */
    dirs?: string[];
    reason?: string;
}
/**
 * Build the model-facing `add_dir` tool.
 * @param deps - resolution + approval + persistence.
 * @returns the tool definition (register with `ctx.tools`).
 */
export declare function defineAddDirTool(deps: AddDirToolDeps): import("@deepseek-ai/dsh-tools").ToolDefinition;
