/**
 * One-time migration from the old "space record" model to the
 * additional-writable-dir model. The previous data file
 * (`{ "spaces": [{ "id", "workspaceId"?, "title"?, "roots": [...] }] }`) is
 * converted to `{ "workspaces": { "<id>": { path, dirs } } }`:
 *
 *   - `roots[0]` (the main root) becomes the record's `path`;
 *   - the remaining roots become `dirs`;
 *   - a record whose `workspaceId` is missing is anchored to the registered
 *     workspace matching one of its roots; if none matches it is dropped
 *     with a warn (its data cannot be attributed).
 *
 * The migration writes into the SQLite store (at `$DSH_CODEX_PROJECT_CONFIG` /
 * `~/.dsh-codex-project/dirs.db`) and leaves the old
 * `~/.dsh-codex-project/spaces.json` untouched as a backup. It is
 * idempotent: once the store holds any record, it never rewrites.
 * @module dsh-codex-project/dirs-migration
 */
import type { WorkspaceRegistryFace } from './dirs-store.ts';
/** The old default data file (pre-rename location, kept literal). */
export declare const LEGACY_SPACES_PATH: string;
/** There is nothing to migrate when the new file already exists. */
export declare function needsMigration(): boolean;
/**
 * Run the migration, writing the new file exactly once.
 * @param registry - the host workspace registry (or a structural fake in tests).
 * @param warn - per-record drop notices (defaults to no-op).
 * @returns the number of records migrated; 0 when nothing was migrated.
 */
export declare function migrateLegacySpaces(registry: WorkspaceRegistryFace, warn?: (message: string) => void): number;
