/**
 * The dsh-codex-project confinement runner: the argv-prefix wrapper the
 * codex-project seam spawns in place of the Linux bwrap profile when a
 * session runs inside a workspace that owns additional writable dirs on
 * Windows. It reads the bwrap-style argv, resolves the workspace whose
 * canonical `path` equals the bind root, and confines the wrapped command
 * under the `@deepseek-ai/dsh-sandbox-windows-acl` restricted token with a
 * WORKSPACE-level write SID granted on EVERY surviving root (`path` + dirs)
 * — the official AclSandbox multi-writable-dir shape, one token, N ACEs,
 * still under workspace-write permission. Sessions outside any recorded
 * workspace (or with a record that has no dirs) keep the core behavior:
 * workspace-write delegates to the core windows-acl runner with the seam's
 * exact grant + argv contract (per-workspace SID), and read-only confines
 * wrapper-locally (no grants exist to share).
 *
 * Stable argv contract (bwrap-compatible subset; the seam builds it):
 *   [node, runner.js, '--ro-bind', '/', '/', '--dev', '/dev',
 *    '--proc', '/proc', '--die-with-parent', '--tmpfs', '/tmp',
 *    '--bind', <root>, <root>, '--', <argv...>]
 * `--ro-bind`/`--dev`/`--proc`/`--die-with-parent` are accepted no-ops
 * (Linux profile markers with no Windows effect). `--tmpfs` selects
 * workspace-write mode; `--bind <src> <dst>` (src === dst only) names the
 * workspace root. Everything after `--` is the confined command.
 *
 * Branches:
 *  - workspace-write + workspace match (the bind root is the canonical
 *    `path` of a record with at least one dir): `AclSandbox({
 *    writableDirs: roots, tempDir, writeSid: workspaceDirsWriteSid(id),
 *    tempWriteSid, mode: 'workspace-write' })` with `manageDacls: true` —
 *    init() materializes the workspace SID's Write ACE on every surviving
 *    root (STANDING, the cross-session reuse cache, exactly like a core
 *    workspace grant) plus the revocable private-temp ACE, spawns with
 *    stdio inherited, and dispose() revokes only the temp ACE. The child's
 *    token carries [workspaceSid, tempSid], so writes pass exactly where a
 *    root or the private temp carries the capability.
 *  - workspace-write otherwise (no record match, or a record with no dirs):
 *    materialize the per-workspace grants (workspace standing, temp
 *    revocable — the core seam's `manageDacls: false` contract) and delegate
 *    to the core runner at `@deepseek-ai/dsh-sandbox-windows-acl/runner`
 *    with its exact argv. Bit-identical to the core seam.
 *  - read-only: `AclSandbox({ writableDirs: [], tempDir: null, mode:
 *    'read-only' })` — the official restricting-list-I token, no capability
 *    SIDs, no grants, ambient temp untouched. (The read-only bwrap profile
 *    carries no workspace root, so there is nothing to delegate.)
 *
 * Workspace discovery: `DSH_CODEX_PROJECT_CONFIG` names a JSON file
 * `{ "workspaces": { "<id>": { path, dirs } } }` (the plugin seam will
 * point it at its data store; the prototype reads it directly). The bind
 * root and each record's `path` are matched in canonical form; a record
 * whose configured dir vanished narrows to the surviving roots — the
 * token's Write ACEs materialize only on roots that still exist, and
 * writes to the dead dir fail naturally (the directory is gone), so a dead
 * dir never poisons unrelated sessions.
 *
 * The workspace SID derives from the config file's canonical directory plus
 * the workspace id via workspaceWriteSid(), NOT from any single root: a
 * workspace SID is a distinct identity, so a core session granted only its
 * own workspace SID cannot follow a workspace root's ACE into another root
 * of the recorded set, and a recorded-workspace session's token cannot use
 * one root's core ACE for a root it was not granted. (Same 2-subauthority
 * shape, different digest input.)
 *
 * Failure contract (mirrors the core runner): every runner-side failure
 * prints `codex-project-run: <detail>` to stderr and exits 127; the confined
 * child is NEVER spawned unrestricted. The wrapper survives a console
 * CTRL+C via no-op signal listeners so the child's exit and the revocations
 * still run — a native-exe wrapper would use the core runner's
 * SetConsoleCtrlHandler instead (prototype limitation).
 * @module dsh-codex-project/runner
 */
export {};
