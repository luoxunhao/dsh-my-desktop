/**
 * Path-containment mechanics for the codex-project fs fence.
 *
 * Faithful copy of `@deepseek-ai/dsh-fs-sandbox/src/containment.ts`
 * (`isPathUnder`): the npm-published package ships only `lib/`, so the
 * internal module cannot be imported; the copy must stay byte-for-byte in
 * behavior with the core (canonical lexical fast path, then filesystem
 * identity fallback for Windows alias spellings). If the core containment
 * ever changes, update this file together with the plugin's fence review.
 * @module dsh-codex-project/containment
 */
/**
 * Determine whether a canonical target is a writable root or lies beneath it.
 * The lexical fast path handles normal canonical spellings. When spellings
 * differ, walk the target's existing ancestors and compare filesystem identity
 * with the root; this recognizes Windows long-name/8.3 aliases and casing
 * without weakening containment to a textual approximation.
 * @param path - canonical target key, which may end in a missing suffix.
 * @param root - canonical writable root.
 * @param caseSensitive - whether lexical comparison preserves case; defaults
 *   to the host filesystem convention used by supported platforms.
 * @returns whether the target is the root or a descendant of it.
 */
export declare function isPathUnder(path: string, root: string, caseSensitive?: boolean): Promise<boolean>;
