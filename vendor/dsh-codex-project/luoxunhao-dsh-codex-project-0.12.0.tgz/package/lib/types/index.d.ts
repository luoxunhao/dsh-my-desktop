import type { Context } from '@deepseek-ai/cordis';
import '@deepseek-ai/dsh-tools';
import '@deepseek-ai/dsh-user-approval';
import type { WorkspaceRegistryFace } from './dirs-store.ts';
/** Plugin identity for cordis.yml rows. */
export declare const name = "@luoxunhao/dsh-codex-project";
/** Services required before mounting: webServer, sessions, workspace registry, tools, approval. */
export declare const inject: string[];
/** Structural mirror of the workspace registry (see dirs-store.ts). */
declare module '@deepseek-ai/cordis' {
    interface Context {
        workspaceRegistry: WorkspaceRegistryFace;
    }
}
/**
 * Plugin body: migrate legacy spaces once, serve the /codex-project/api
 * routes, refresh the session reminder (text-idempotent), register the
 * add-dir tool, and wrap the sandbox confine.
 * @param ctx - the host cordis context (webServer, sessions, workspaceRegistry, tools, approval).
 */
export declare function apply(ctx: Context): void;
