/**
 * Recursive project file-name search for the 项目文件夹 tab's toolbar box: a
 * read-only walk of a project's roots (main root + surviving shared dirs)
 * returning files/dirs whose basename contains the query (case-insensitive).
 * A symlink is only reported / descended into when its resolved target stays
 * under the root it was found in, so the walk never surfaces paths outside the
 * fence. Kept local to the plugin — mirrors better-sidebar's global file search
 * feed without importing that plugin's runtime symbols.
 * @module dsh-codex-project/project-search
 */
/** One search hit: an absolute path plus its matched basename. */
export interface SearchResult {
    path: string;
    name: string;
}
/** Default cap on total hits (better-sidebar bounds its search similarly). */
export declare const SEARCH_CAP = 400;
/**
 * Recursively collect project entries whose basename contains `query`
 * (lowercased, case-insensitive), bounded by `cap`. Each root's tree is walked
 * with read-only `opendir`; symlink directories whose target escapes the root
 * are not descended into, and matching symlink files are only reported when
 * their target stays under the root. Results are deduped by absolute path in
 * case roots nest/overlap.
 * @param roots - the project's writable roots (main root + surviving dirs).
 * @param query - the needle; an empty/whitespace query returns [].
 * @param cap - the total-result bound (further matches are dropped).
 * @returns the matching entries.
 */
export declare function searchProjectFiles(roots: readonly string[], query: string, cap?: number): Promise<SearchResult[]>;
