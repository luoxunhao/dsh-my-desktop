/**
 * dsh-codex-project configuration store: the read-modify-write layer over the
 * SQLite dirs database (`$DSH_CODEX_PROJECT_CONFIG` or
 * `~/.dsh-codex-project/dirs.db`, owned by `src/dirs-config.ts`). Writes
 * replace the whole record set inside one SQLite transaction (no temp file +
 * rename, so the Windows EPERM that plagued a JSON config never applies) and
 * are serialized through a promise queue so interleaved requests cannot lose
 * updates; reads go straight to the shared loader. Every mutation validates
 * that each directory exists (a saved dir must be runnable; a dir vanishing
 * later merely narrows the grant at confinement time).
 * @module dsh-codex-project/dirs-store
 */
import type { WorkspaceDirs } from './dirs-config.ts';
/** A mutation/query failure: invalid request, unknown workspace, or a fenced path. */
export declare class DirsStoreError extends Error {
    /** `not-found` (unknown workspace), `invalid` (bad shape/missing dir), or `forbidden` (fence). */
    readonly code: 'not-found' | 'invalid' | 'forbidden';
    constructor(
    /** `not-found` (unknown workspace), `invalid` (bad shape/missing dir), or `forbidden` (fence). */
    code: 'not-found' | 'invalid' | 'forbidden', message: string);
}
/** The host workspace registry face (structural; see @deepseek-ai/dsh-workspace). */
export interface WorkspaceRegistryFace {
    /** Fresh ordered workspace projection (canonical paths). */
    list(): Array<{
        id: string;
        path: string;
    }>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        workspaceRegistry: WorkspaceRegistryFace;
    }
}
/** Serialize one mutation over the record set, atomically (SQLite transaction). */
export declare class DirsStore {
    private queue;
    private enqueue;
    /** The configured records (shared loader; a malformed row fails loud). */
    load(): Promise<Record<string, WorkspaceDirs>>;
    /**
     * Replace one workspace's additional dirs. The workspace must already have
     * a record (created by migration or by anchoring a registry workspace).
     * Every dir must exist and be a directory; empty arrays clear the extras.
     * @param workspaceId - the owning workspace.
     * @param dirs - the additional writable dirs (may be empty).
     * @returns the updated record.
     */
    setDirs(workspaceId: string, dirs: string[]): Promise<WorkspaceDirs>;
    /**
     * Anchor a registry workspace (id + canonical path) with the given dirs,
     * creating the record when absent. Idempotent: an existing record keeps
     * its dirs unless `dirs` is provided.
     * @param workspaceId - the owning workspace.
     * @param path - the canonical main workspace path.
     * @param dirs - optional initial additional dirs.
     * @returns the record.
     */
    anchor(workspaceId: string, path: string, dirs?: string[]): Promise<WorkspaceDirs>;
    /** Remove one workspace's record (add-dir is additive; removal is explicit). */
    remove(workspaceId: string): Promise<void>;
}
/**
 * Persist the full record map. Retained under its original name because
 * `dirs-migration.ts` imports it; the write is a single SQLite transaction.
 * @param records - the full record map.
 */
export declare function persistWorkspaceDirs(records: Record<string, WorkspaceDirs>): void;
