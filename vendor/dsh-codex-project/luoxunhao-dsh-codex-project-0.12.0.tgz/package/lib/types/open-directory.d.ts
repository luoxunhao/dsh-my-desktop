/**
 * 打开本地目录 — the host-side native action behind the workspace menu's
 * 打开本地目录 row. Runs as a plugin-owned route
 * (`POST /codex-project/api/open-directory`) that spawns the OS file manager
 * directly. Deliberately NOT `workspaces.openPath`: that method is the
 * chat-side file-open funnel, and dsh-better-sidebar wraps it to route opens
 * into its sidebar editor — a directory has no meaning there and surfaces
 * as `"<path>" is a directory` in the sidebar. A plugin-owned route keeps
 * the action independent of any other plugin's interception.
 *
 * Validation: the payload must carry an absolute path that exists as a
 * directory; the spawn is detached and unref'd (explorer.exe reports exit
 * code 1 even on success, so the child's outcome is never consulted).
 * @module dsh-codex-project/open-directory
 */
/** The open side effect, injectable for tests. */
export type DirectoryOpener = (path: string) => void;
/** Default opener: start the OS file manager detached and never block on it. */
export declare const openWithFileManager: DirectoryOpener;
/**
 * Handle one open-directory request: validate and spawn the file manager.
 * @param body - the JSON request body (`{ path }`).
 * @param open - the opener (defaults to the OS file manager).
 * @returns the wire result.
 */
export declare function openDirectoryRequest(body: unknown, open?: DirectoryOpener): {
    status: number;
    body: {
        ok: true;
    } | {
        ok: false;
        error: string;
    };
};
