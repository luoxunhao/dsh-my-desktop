/**
 * Seam wiring: route `ctx.sandbox.confine` through the dsh-codex-project
 * multi-root runner for sessions whose workspace owns an
 * additional-writable-dir record. The wrapping is the plugin's only touch on
 * the core sandbox service — the core's `runnerCommand` config surface is
 * left alone (its static argv cannot carry a dynamically resolved runner
 * path), and everything else the plugin does (config CRUD, UI) composes
 * through its own services.
 *
 * Routing decision per confine call (pure superset of the core seam):
 *  - non-Windows, non-`workspace-write`, a session cwd outside every
 *    record, or a record with no dirs → the ORIGINAL confine (core
 *    behavior, bit-identical);
 *  - otherwise → the dsh-codex-project runner with the bwrap
 *    workspace-write profile argv (the exact shape the core
 *    `bwrapProfileArgs(policy)` builds for workspace-write — the wrapper
 *    parses it back; keep the two in lockstep), which grants a
 *    workspace-level SID on every surviving root and confines under one
 *    restricted token.
 *
 * A configured dir that vanished narrows the grant to the surviving roots
 * (the canonical match never throws): the runner materializes grants only on
 * roots that still exist, exactly like the fs fence and the context
 * injection — a dead directory must not poison unrelated sessions.
 * @module dsh-codex-project/seam
 */
import type { SandboxProvider } from '@deepseek-ai/dsh-sandbox';
/**
 * The bwrap workspace-write profile the wrapper parses: the exact argv
 * `@deepseek-ai/dsh-sandbox-local`'s `bwrapProfileArgs(policy)` builds for
 * workspace-write. Keep this and the wrapper's parser in lockstep.
 */
export declare function bwrapWorkspaceWriteArgs(workspaceRoot: string): string[];
/**
 * Wrap one sandbox provider's confine in the codex-project routing.
 * @param sandbox - the sandbox service instance (`ctx.get('sandbox')`).
 * @param runnerPath - absolute path of the built `lib/runner.js`.
 * @returns a disposer restoring the original confine (fiber teardown; HMR
 *   reloads re-apply the whole tree, so a fresh provider gets wrapped again).
 */
export declare function wrapSandboxConfine(sandbox: SandboxProvider, runnerPath: string): () => void;
