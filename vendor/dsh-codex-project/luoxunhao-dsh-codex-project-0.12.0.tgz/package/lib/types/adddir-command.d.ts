/**
 * The `/adddir` human command: the operator-facing counterpart of the
 * `add_dir` model tool. The operator types `/adddir` in the composer, a
 * native directory picker opens on the host, and the chosen folder joins the
 * ADDITIONAL writable dirs of the active session's workspace — no approval
 * prompt (the operator explicitly picked it). Registered through the dsh
 * host `commands` service as a plain global command (name `adddir`, no
 * leading slash), which is enough for it to appear in the composer `/` menu
 * and run (the browser command catalog is pulled live from the host).
 *
 * Picker: reads the host `ctx.directoryPicker` seam. Only the `native`
 * capability (an OS chooser on the host display) fits a no-arg command; a
 * `browse` backend or an absent service yields a clear error instead of
 * guessing. dsh model tools are `add_dir` (underscore); the matching user
 * command is `/adddir`.
 * @module dsh-codex-project/adddir-command
 */
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { DirsStore } from './dirs-store.ts';
/** One resolved slash command result (host @deepseek-ai/dsh-commands). */
export type AdddirCommandResult = {
    readonly kind: 'success';
    readonly text?: string;
} | {
    readonly kind: 'error';
    readonly text: string;
};
/** Invocation passed to a registered command handler. */
export interface AdddirCommandInvocation {
    /** Exact agent whose UI received the command. */
    readonly agent: Agent;
    /** Cancellation signal owned by the dispatching UI request. */
    readonly signal: AbortSignal;
}
/** The command registration the `commands` service accepts (host face). */
export interface AdddirCommandDefinition {
    readonly name: string;
    readonly description: string;
    readonly handler: (invocation: AdddirCommandInvocation) => AdddirCommandResult | Promise<AdddirCommandResult>;
}
/** The `commands` host service face (register only). */
export interface CommandsServiceFace {
    register(definition: AdddirCommandDefinition): () => void;
}
/** The native directory-picker capability (host seam). */
export interface NativeDirectoryPicker {
    readonly kind: 'native';
    pick(signal: AbortSignal): Promise<string | null>;
}
/** The `directoryPicker` host service face (capability only). */
export interface DirectoryPickerServiceFace {
    capability(): NativeDirectoryPicker | {
        readonly kind: 'browse';
    } | {
        readonly kind: string;
    };
}
/** Deps the `/adddir` command needs (wired in index.ts). */
export interface AdddirCommandDeps {
    /** Resolve the owning workspace id of a session cwd (shared with the model tool). */
    resolveWorkspaceId(cwd: string): string | undefined;
    /** The host directory picker, or undefined when none is composed. */
    picker(): DirectoryPickerServiceFace | undefined;
    /** Persist the additional writable dirs. */
    store: DirsStore;
}
/** Build the host `/adddir` command. */
export declare function defineAdddirCommand(deps: AdddirCommandDeps): AdddirCommandDefinition;
