/**
 * Native workspace 「…」 menu injection: the workspace row's overflow menu is
 * ui-workspace code with hardcoded items (rename/delete) and an `onSelect`
 * that rejects unknown ids — so the plugin adds its own items at the DOM
 * level: a MutationObserver watches for the portalled `[role="menu"]` popup
 * that appears while a workspace row carries the `menuOpen` class, injects
 * a two-row block into the popup's viewport, and binds its own click
 * handlers (which never go through the native `onSelect`).
 *
 * Injected rows:
 *  - 打开本地目录 — opens the workspace's folder in the OS file manager via
 *    the plugin's own host route (`/codex-project/api/open-directory`, which
 *    spawns explorer.exe). Deliberately NOT `workspaces.openPath`:
 *    dsh-better-sidebar wraps that method into its sidebar editor, where a
 *    directory is meaningless (`"<path>" is a directory`).
 *  - 管理工作区 — opens the plugin's manage dialog (`WorkspaceDialog`),
 *    which lists the shared subdirectories and offers the 设为主工作区
 *    handover.
 *
 * Click flow: identify the workspace (row title → workspace registry) →
 * close the menu (Escape, the native document keydown listener) → run the
 * action.
 *
 * The popup unmounts on close, so the injected rows die with it — every
 * open re-injects (self-healing by construction). Keyboard navigation of
 * the native menu does not see the injected rows; mouse clicks work.
 *
 * The rows mirror the native menu cell structure and metrics (16px leading
 * icon + label, 40px min-height cell) so they render pixel-identical to the
 * native 重命名 row; the CSS lives in `styles.ts`.
 * @module dsh-codex-project/client/workspace-menu
 */
import type { SpacesApi } from './api.ts';
import type { ClientWorkspacesService } from './context.ts';
/** The injected block's identity (idempotent per-popup injection). */
export declare const MENU_ACTIONS_SELECTOR = "[data-dsh-codex-project-menu-actions]";
/** The 管理工作区 row (kept for tests and direct queries). */
export declare const MENU_MANAGE_SELECTOR = "[data-dsh-codex-project-menu-manage]";
/** The 打开本地目录 row. */
export declare const MENU_OPEN_DIRECTORY_SELECTOR = "[data-dsh-codex-project-menu-open-directory]";
/** The dialog host's identity (one dialog at a time). */
export declare const DIALOG_SELECTOR = "[data-dsh-codex-project-dialog]";
/**
 * Mount the 「…」 menu injection (打开本地目录 + 管理工作区) and its manage
 * dialog.
 * @param deps - the workspaces service (identity) and the spaces API.
 * @returns the disposer.
 */
export declare function mountWorkspaceMenuManageEntry(deps: {
    workspaces: ClientWorkspacesService;
    api: SpacesApi;
}): () => void;
