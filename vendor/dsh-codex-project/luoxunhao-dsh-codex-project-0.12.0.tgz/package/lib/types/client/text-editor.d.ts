/**
 * The inline code/markdown/html file editor for the 项目文件夹 tab's preview
 * pane: a CodeMirror 6 editor with line wrapping, extension-keyed syntax
 * highlighting, a dirty dot and Ctrl/Cmd+S save (through the plugin's /write
 * route), plus a preview/edit toggle for markdown (MarkdownText from the
 * shared primitives) and html (sandboxed iframe). The parent preview pane
 * fetches the content through /read and passes it in props; this component
 * only edits and saves — it never fetches.
 *
 * CodeMirror and the language packages are plain (non-`@deepseek-ai`)
 * dependencies, so they are inlined into the plugin's client bundle — the
 * purity gate only rejects value-imports of other `@deepseek-ai` runtime
 * symbols.
 * @module dsh-codex-project/client/text-editor
 */
import { type ReactNode } from 'react';
import type { SpacesApi } from './api.ts';
/** The props of the text editor: already-fetched content plus the save API. */
export interface TextEditorProps {
    api: SpacesApi;
    cwd: string;
    path: string;
    content: string;
    truncated: boolean;
    kind: 'markdown' | 'html' | 'code';
}
/**
 * The code/markdown/html editor. Markdown/html start in preview mode
 * (rendered output); code files start in edit mode. The CodeMirror view is
 * created once per file path and kept alive, so toggling modes never loses an
 * un-saved draft; `content` re-seeds the view only when the file changes.
 *
 * The CodeMirror host is ALWAYS mounted (hidden via CSS in preview mode) so
 * the view-creation effect runs on mount regardless of the initial mode —
 * keying it on `mode` or rendering the host only in edit mode would leave the
 * editor blank until the file changes.
 */
export declare function TextEditor(props: TextEditorProps): ReactNode;
