/**
 * The 管理工作区 dialog: the plugin's own small popup (rendered into
 * `document.body`, closed by Escape / outside click / the close button) that
 * manages one workspace's ADDITIONAL writable directories.
 *
 * Face: shows the workspace's own path (read-only) plus its additional-dir
 * list (each removable) and an 添加 button that opens an IN-PAGE folder picker
 * (`FolderPicker`). The picker replaces any OS-native folder dialog: native
 * dialogs spawned by the background dsh web process never grab the foreground
 * (they open behind the browser), so the selection is rendered in-page, where
 * it is always on top of the GUI and focused.
 * @module dsh-codex-project/client/workspace-dialog
 */
import { type ReactNode } from 'react';
import type { SpacesApi } from './api.ts';
import type { ClientWorkspacesService, ClientWorkspaceView } from './context.ts';
/** The dialog's injected face. */
export interface WorkspaceDialogProps {
    /** The workspace whose 「…」 menu was clicked. */
    workspace: ClientWorkspaceView;
    api: SpacesApi;
    workspaces: ClientWorkspacesService;
    /** Close the dialog. */
    onClose(): void;
}
/**
 * The manage-dialog body.
 * @param props - the workspace, the dirs API, the workspaces service, and the close callback.
 */
export declare function WorkspaceDialog(props: WorkspaceDialogProps): ReactNode;
