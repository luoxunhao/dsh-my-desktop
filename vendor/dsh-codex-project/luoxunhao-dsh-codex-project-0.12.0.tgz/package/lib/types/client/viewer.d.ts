/**
 * Viewer classification for the 项目文件夹 tab's inline preview: map a file
 * path to a preview kind, and detect binary payloads from their first bytes.
 * Pure string/int logic — no node:path, no DOM.
 * @module dsh-codex-project/client/viewer
 */
/** The preview kind a file maps to. `code` is the catch-all text viewer. */
export type ViewerKind = 'image' | 'pdf' | 'markdown' | 'html' | 'code' | 'binary';
/** Extension (without dot, lowercased) of an absolute path. */
export declare function extensionOf(path: string): string;
/** The preview kind for a path, by extension. `code` is the fallback. */
export declare function viewerKindForPath(path: string): ViewerKind;
/** Whether a text slice is actually binary — NUL bytes in the first bytes. */
export declare function looksBinary(content: string): boolean;
