/**
 * The 项目文件夹 tab's inline preview pane: given an absolute file path, it
 * fetches and renders the right viewer — image (plain `<img>` over the /file
 * route), PDF (native browser viewer over a Blob URL), binary (download
 * button), or the CodeMirror text editor (markdown/html preview, code edit).
 * Text content is read through /read; a NUL-byte first chunk flips a
 * "text" file to the binary download viewer.
 * @module dsh-codex-project/client/preview-pane
 */
import { type ReactNode } from 'react';
import type { SpacesApi } from './api.ts';
/** The props of the preview pane. */
export interface PreviewPaneProps {
    api: SpacesApi;
    cwd: string;
    path: string;
}
/**
 * The preview pane body for one open file.
 * @param props - the dirs API, the session cwd, and the file path to preview.
 */
export declare function PreviewPane(props: PreviewPaneProps): ReactNode;
