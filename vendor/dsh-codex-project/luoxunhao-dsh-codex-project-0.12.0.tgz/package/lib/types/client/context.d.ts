/**
 * Client-half Context for dsh-codex-project. The client runtime's Context
 * is a local face: upstream `declare module 'cordis'` augmentations do not
 * reach it, so the plugin declares the services it uses structurally (see
 * DSH-better-sidebar/src/context-types.ts for the full pattern). Only the
 * slices the plugin touches are restated; drift from upstream is contained
 * to this file.
 */
/** One registered workspace row (subset of the wire WorkspaceView). */
export interface ClientWorkspaceView {
    workspaceId: string;
    /** Canonical directory path (host-side realpath canon). */
    path: string;
    /** Display title (defaults to the path basename at create). */
    title: string;
}
/** The workspace registry snapshot the dialog reads for record identities. */
export interface ClientWorkspaceListState {
    items: readonly ClientWorkspaceView[];
}
/** The workspaces-service face the client bundle consumes (subset of the real surface). */
export interface ClientWorkspacesService {
    /** The workspace registry feed (record main-workspace identities). */
    list: {
        getSnapshot(): ClientWorkspaceListState;
        subscribe(fn: () => void): () => void;
    };
    /**
     * Register an existing path as a core Workspace (idempotent). Returns the
     * wire `WorkspaceView` — its id field is `workspaceId`.
     */
    create(input: {
        path: string;
    }): Promise<{
        workspaceId: string;
    }>;
}
/**
 * The better-sidebar service face the project tab consumes — restated
 * structurally like the workspaces slice (upstream augmentations do not reach
 * this bundle). `registerTab` registers a sidebar page; `openTab` opens a tab
 * of a registered type with an optional file path (used to open the 项目文件夹
 * file preview in its own sidebar tab). `ctx.betterSidebar` is OPTIONAL: these
 * register only when better-sidebar is installed.
 */
export interface OpenTabSeed {
    /** The registered tab type id (e.g. 'codex-project:project'). */
    type: string;
    /** Overrides the descriptor's title (the preview tab shows the file name). */
    title?: string;
    /** A file path (the preview tab's content seed). */
    path?: string;
    /** Explicit tab id (defaults to the type; use a path-derived id to dedupe). */
    id?: string;
    /** JSON-serializable custom state carried on the minted tab. */
    meta?: unknown;
}
export interface SidebarTabDescriptor {
    id: string;
    title: string | (() => string);
    icon?: unknown;
    order?: number;
    /** `single: true` dedupes opens of the same type (focus instead of re-open). */
    single?: boolean;
    /** Hide from the sidebar + menu (the preview tab is only opened programmatically). */
    hidden?: boolean;
    component: (props: SidebarTabComponentProps) => unknown;
}
/** The better-sidebar client service face (subset actually consumed). */
export interface BetterSidebarService {
    registerTab(descriptor: SidebarTabDescriptor): () => void;
    /**
     * Open a tab of a registered type. A content seed (path) opens a preview/editor
     * tab for that file; a type-only seed opens a blank page of the type.
     */
    openTab(seed: OpenTabSeed, scope?: SidebarTabScope): void;
}
/** One session scope: the session id plus its working directory. */
export interface SidebarTabScope {
    sessionId: string;
    cwd?: string;
}
/**
 * The props better-sidebar passes to a registered tab's `component`. Only the
 * slices the tab touches are restated: the client `ctx` (for the composer
 * draft), the session `scope`, and the minted `tab` (whose `path`/`meta` seed
 * the preview tab — better-sidebar always passes these at runtime regardless
 * of what this structural face declares).
 */
export interface SidebarTabComponentProps {
    ctx: ClientRuntimeContext;
    scope: SidebarTabScope;
    /** The current tab instance (its `path` seeds the file preview tab). */
    tab?: {
        path?: string;
        title?: string;
        meta?: unknown;
    };
}
/** One session row of the client session projection (subset actually consumed). */
export interface ClientSessionSummary {
    /** The session's working directory; absent while the projection is cold. */
    cwd?: string;
}
/** The session list snapshot: rows keyed by session id. */
export interface ClientSessionListState {
    byId: Record<string, ClientSessionSummary | undefined>;
}
/**
 * The client runtime context face the tab and the `@` source consume: the
 * conversation service (`get('conversation')`) plus the session registry —
 * both reached lazily so a missing service degrades to a logged no-op, never a
 * crash. The session list carries each session's cwd, which the `@` source
 * needs to resolve the project roots its candidates come from.
 */
export interface ClientRuntimeContext {
    get(service: string): unknown;
    sessions: {
        scope(sessionId: string): unknown;
        list?: {
            getSnapshot(): ClientSessionListState;
        };
    };
}
/** One reference-chip occurrence in the composer draft (clipboard coordinates). */
export interface DraftOccurrence {
    /** Clipboard offset of the chip's clipboard projection. */
    offset: number;
    /** Length of the chip's clipboard projection. */
    length: number;
}
/** The composer draft input face (subset of the conversation service). */
export interface DraftInput {
    input: {
        for(sessionScope: unknown): {
            state: {
                getSnapshot(): {
                    /** Clipboard-text projection of the editor document (chips expanded). */
                    draft: string;
                    /** Reference-chip occurrences, in clipboard coordinates. */
                    occurrences: readonly DraftOccurrence[];
                    /** Input revision (CAS for every slash/input-* edit). */
                    draftRev: number;
                };
            };
            setDraft(text: string): void;
        };
    };
}
/**
 * One inline file-reference chip the plugin injects into the composer. The
 * draft holds one placeholder per chip; the owner supplies the user-facing
 * projections at insert time (label = the chip text, clipboardText = the
 * copy/persistence form), and a registered source's codec serializes `ref`
 * into the model context on submit. `source` must name a registered source.
 */
export interface FileReferenceInsert {
    source: string;
    ref: string;
    label: string;
    clipboardText: string;
    /** Chip glyph: a directory renders as a folder, a file as a file. */
    appearance?: 'file' | 'folder' | 'session';
}
/**
 * A zero-width insertion span in DETECT coordinates (the plane the composer's
 * `slash/input-insert-reference` expects, where each chip counts as one U+FFFC),
 * plus the CAS revision. `start`/`end` are equal (a collapsed span at the true
 * detect end); `draftRev` must be the current input revision or the edit is
 * rejected.
 */
export interface FileReferenceSpan {
    /** Detect offset of the insertion point (must equal `end`). */
    start: number;
    /** Detect offset of the insertion point (must equal `start`). */
    end: number;
    /** Input revision (CAS). */
    draftRev: number;
}
/** The client input-trigger service face (subset actually consumed). */
export interface ClientInputTriggerService {
    registerSource(source: unknown): () => void;
}
/** The client cordis context for this plugin. */
export interface Context {
    workspaces: ClientWorkspacesService;
    /** The better-sidebar service, present only when that plugin is installed. */
    betterSidebar?: BetterSidebarService;
    /** The input-trigger roster, present only when that plugin is installed. */
    inputTriggers?: ClientInputTriggerService;
    /** Register a fiber teardown callback (cordis Context face). */
    effect(callback: () => void | (() => void), name?: string): void;
    /** Read a service from the reflect store without inject requirement (cordis Context face). */
    get(name: string): unknown;
}
