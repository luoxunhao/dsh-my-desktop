import type { Context } from './context.ts';
/** Services required before mounting (provided by the client runtime; the
 *  `betterSidebar` is OPTIONAL: cordis keeps the fiber pending when missing, so we omit it from inject. */
export declare const inject: string[];
/**
 * Client plugin body.
 * @param ctx - the client cordis context (workspaces).
 */
export declare function apply(ctx: Context): void;
