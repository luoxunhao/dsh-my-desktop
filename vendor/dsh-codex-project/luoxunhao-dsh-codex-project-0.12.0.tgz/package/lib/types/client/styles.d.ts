/**
 * Project-space DOM styles, injected once as a `<style>` tag (data-plugin
 * guarded). Attribute-scoped so nothing leaks into the rest of the GUI;
 * colors ride the dsh `--dsw-*` tokens so the entries follow the active
 * theme (light/dark/skins), mirroring the reference dsh-web-ui panels.
 * @module dsh-codex-project/client/styles
 */
/** Inject the styles once; a repeated call is a no-op. */
export declare function injectStyles(): () => void;
