/**
 * FolderPicker — the in-page 选择目录 browser inside the 管理工作区 dialog.
 *
 * It replaces the OS-native folder dialog for 添加附加目录: native dialogs
 * spawned by the background dsh web process (windowsHide) never grab the
 * foreground, so they open behind the browser — and passing the browser window
 * as an owner breaks the dialog entirely. An in-page browser is always on top
 * of the GUI and has focus by construction.
 *
 * UX: start at the workspace's own path; show its subdirectories; clicking a
 * directory descends; up/home ascends to the drive roots; a PATH INPUT accepts
 * native (`C:\`, `C:/Users/...`) and Git-Bash Linux-style (`/c`, `/d`,
 * `/c/Users/...`) paths and jumps there (on Win10 typing `/c` / `/d` goes to a
 * drive root). The user selects the CURRENT directory as the additional
 * writable dir.
 *
 * Data comes from the plugin's own unbounded (loopback, read-only) pick-browse
 * host feed, so it needs no DSH directory-picker backend.
 * @module dsh-codex-project/client/folder-picker
 */
import { type ReactNode } from 'react';
import type { SpacesApi } from './api.ts';
/** The picker's injected face. */
export interface FolderPickerProps {
    api: SpacesApi;
    /** The directory to open at (the workspace's own path). */
    initialPath: string;
    /** Confirm the currently-viewed directory as the selection. */
    onPick(path: string): void;
    /** Dismiss without a selection. */
    onCancel(): void;
}
/**
 * The in-page directory browser body.
 * @param props - the api, the initial path, and the pick/cancel callbacks.
 */
export declare function FolderPicker(props: FolderPickerProps): ReactNode;
