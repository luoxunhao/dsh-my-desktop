/**
 * The `@` reference source of the 项目文件夹 project. Referencing a file no
 * longer drops plain text into the composer — it injects a proper reference
 * chip through the conversation input's scoped `slash/input-insert-reference`
 * event. The chip shows the FILE NAME (`label`) in the composer, and on submit
 * the registered source's codec serializes the ABSOLUTE path (inline-code
 * form, the harness's recognized file-tool path) into the model context.
 *
 * The source is ALSO a real `@`-menu source, shaped after the harness's own
 * `ui-reference` source (`packages/client/ui-reference`): it browses the
 * project — main root plus every shared additional dir (cross-drive) — one
 * directory level at a time. A directory row carries `drill`, so Tab (or the
 * row chevron) descends into it and keeps the menu open; a drilled listing
 * publishes breadcrumbs (`header`) so the user can climb back out. That
 * level-by-level descent is what core discovery cannot do: core discovery is
 * rooted at the session cwd alone, so shared dirs outside it stay invisible to
 * `@` without this source.
 *
 * Descent rides the DRAFT TEXT, exactly like the harness: a drill pick returns
 * `{ text, continue: true }`, the pipeline rewrites the trigger token and
 * re-queries every source with the deeper query. The text is the absolute path
 * in `@path/` (or `@"path/` when it contains spaces) form — the project is
 * multi-rooted, so a bare relative path could not name a destination.
 *
 * All types are restated structurally — the client bundle's purity gate
 * forbids value-importing the input-trigger package.
 * @module dsh-codex-project/client/file-reference
 */
import type { SpacesApi } from './api.ts';
import type { ClientRuntimeContext, SidebarTabScope } from './context.ts';
/** The registered source name; the chip's `source` routes here for serialization. */
export declare const FILE_REF_SOURCE = "codex-project:file";
/** One row's opaque pick payload: what it is, where it lives, and its trigger text. */
export interface ProjectReferenceValue {
    kind: 'dir' | 'file';
    /** Absolute path, separators normalized to `/`. */
    path: string;
    /** The trigger text this row writes back (drill text or chip mention). */
    mention: string;
}
/**
 * The source's dependencies: the project API and a session→cwd projection.
 * Both are supplied at registration so the source stays a pure function of its
 * inputs under test.
 */
export interface ProjectReferenceDeps {
    api: Pick<SpacesApi, 'project' | 'listDir'>;
    /** The session's working directory, or undefined while the projection is cold. */
    cwdFor?(sessionId: string): string | undefined;
}
/** The project roots one session sees: the anchor plus surviving shared dirs. */
export interface ProjectRoots {
    cwd: string;
    /** Main root (== the session cwd). */
    main: string;
    /** Additional shared directories, in configured order. */
    dirs: readonly string[];
}
/** One menu candidate (structural mirror of the input-trigger contract). */
export interface ProjectCandidate {
    name: string;
    description?: string;
    icon?: 'file' | 'folder';
    section?: string;
    value: string;
    drill?: boolean;
}
/** One breadcrumb step (structural mirror of the input-trigger contract). */
export interface ProjectCrumb {
    label: string;
    value: string;
    current?: boolean;
}
/**
 * Split one trigger query into the directory being listed and the fragment
 * typed after its last separator — core's `WorkspaceFileSearch.list` protocol,
 * where a slash-bearing query IS the request to descend.
 * @param query - path text following `@` or `@"`.
 */
export declare function splitQuery(query: string): {
    directory: string;
    fragment: string;
};
/**
 * Render one destination as trigger text, following core's `formatFileMention`
 * grammar: a directory keeps its trailing slash open so the next query can
 * descend another level, and a path containing whitespace is quoted. Control
 * characters and quotes cannot be written back at all.
 * @param path - absolute path, separators normalized to `/`.
 * @param isDirectory - whether the destination is a directory.
 * @param quoted - retain an explicitly opened quote even when unnecessary.
 * @returns the insertion text, or undefined when the grammar cannot represent it.
 */
export declare function formatProjectMention(path: string, isDirectory: boolean, quoted?: boolean): string | undefined;
/** Normalize one absolute path to forward slashes, dropping trailing separators. */
export declare function normalize(path: string): string;
/** The root an absolute path belongs to, or undefined when it escapes the project. */
export declare function rootFor(roots: ProjectRoots, path: string): string | undefined;
/**
 * Resolve the directory a query names against the project roots. A query is
 * absolute once a drill wrote one back; a hand-typed query is relative and
 * resolves under the main root. Paths that leave the project — after `..` is
 * folded — yield undefined: the host refuses them anyway, and this source
 * simply offers nothing.
 * @param roots - the project roots.
 * @param directory - the query's directory part (empty at the project root).
 */
export declare function resolveQueryDirectory(roots: ProjectRoots, directory: string): string | undefined;
/**
 * The breadcrumb of a drilled listing: one step from the containing root down
 * to the directory being listed. Only a drill produces one — a path the user
 * typed carries its own context in the draft, while a drill replaced the text
 * they were reading and owes them the way back (core's `crumbsFor` rule).
 * @param roots - the project roots.
 * @param query - the live trigger query.
 * @param quoted - whether the active token is an open quoted path.
 * @param drilled - whether a drill pick, rather than typing, produced the query.
 * @returns the crumbs, or undefined when this listing needs no header.
 */
export declare function crumbsFor(roots: ProjectRoots, query: string, quoted: boolean, drilled: boolean): readonly ProjectCrumb[] | undefined;
/** Decode one row's payload, tolerating rows this source did not produce. */
export declare function decodeValue(value: string | undefined): ProjectReferenceValue | undefined;
/**
 * Build the project `@` source: one directory level at a time over the session
 * project's main root plus every shared additional dir, with drill-down
 * descent and breadcrumbs — the multi-root answer to core's cwd-rooted
 * `@files`.
 *
 * The source serves the session that opened the menu and nothing else: its
 * roots are the project anchored at that session's cwd, resolved exactly like
 * the 项目文件夹 tab (`/project` + `/list`, fenced to the project). When no
 * project anchors the cwd, the source contributes nothing — like core
 * discovery, an unanchored session sees no project files.
 * @param api - the project API.
 * @param deps - optional source dependencies (a session→cwd projection).
 */
export declare function createFileReferenceSource(api: SpacesApi | undefined, deps?: {
    cwdFor?(sessionId: string): string | undefined;
}): unknown;
/**
 * The composer's TRUE detect end: the offset (in DETECT coordinates) at which a
 * new reference chip should be appended. The composer's `slash/input-insert-reference`
 * span is expressed in detect coordinates, where each existing chip counts as one
 * U+FFFC — but the public InputState exposes only the CLIPBOARD draft, where a chip
 * expands to its (long) clipboard text. Plain text/gaps/newlines count 1:1 in both
 * planes, so the detect end is exactly the clipboard length minus one per extra
 * char each chip contributes (`occ.length − 1`). Computing this fresh before EVERY
 * insert lets multiple genuine chips stack (see insertFileReference).
 * @param draft - the clipboard draft text (`state.draft`).
 * @param occurrences - the chip occurrences in clipboard coordinates (`state.occurrences`).
 * @returns the detect length (== the correct collapsed insert offset for a new chip).
 */
export declare function detectEnd(draft: string, occurrences: readonly {
    offset: number;
    length: number;
}[]): number;
/**
 * Inject one file/directory reference chip into the session composer draft as a
 * GENUINE dsh reference chip (the same chip the native `@` picker makes). Each
 * call appends ONE chip at the composer's current DETECT end; re-reading the
 * input state fresh every call lets several references stack into one composer
 * (each chip keeps its own address, exactly like N user-typed `@` tokens).
 *
 * Directories carry the trailing slash the harness prompt reads as "list it when
 * its contents matter". Degrades to a logged no-op when the conversation service,
 * session scope, or input shell is unavailable.
 * @param ctx - the client runtime context.
 * @param scope - the target session.
 * @param path - absolute path of the referenced file or directory.
 * @param options - `isDirectory` marks a directory reference.
 */
export declare function insertFileReference(ctx: ClientRuntimeContext, scope: SidebarTabScope, path: string, options?: {
    isDirectory?: boolean;
}): void;
