/**
 * Client-side path helpers for the codex-project UI. The browser bundle can
 * never import `node:path`, so the few string operations the tree, the file
 * panel, and the '@' source need live here (display names + Windows-safe
 * equality).
 * @module dsh-codex-project/client/paths
 */
/** The trailing path segment of an absolute or relative path (no node:path). */
export declare function basename(path: string): string;
/**
 * Whether two absolute paths address the same directory, per the host
 * platform's case convention (Windows paths compare case-insensitively).
 */
export declare function samePath(a: string, b: string): boolean;
/**
 * A slash-joined, `..`-normalized path from `from` to `target` (no node:path).
 * Cross-drive (no common prefix, e.g. `C:\…` vs `D:\…`) or unrelated paths
 * return `target` unchanged — the caller falls back to the absolute form.
 */
export declare function relativePath(from: string, target: string): string;
/**
 * Resolve a path-box input against the session cwd into a normalized absolute
 * path (no node:path in the browser bundle). Absolute inputs pass through
 * (drive letter preserved); relative inputs join under the cwd and `..`/`.`
 * are folded. The result need not exist — the host read rejects it.
 */
export declare function resolvePath(cwd: string, input: string): string;
