/**
 * The native DSH right-Sidebar integration (DSH 0.1.6): the 项目文件夹 tree
 * and its per-file 文件预览, registered through the official two-stage path —
 * the type into `ctx.sidebarRightTabs`, the body into the keyed
 * `sidebar.right.pane.tab` seat and the chip title into
 * `sidebar.right.pane.tab.title`, both under the definition's `id`.
 *
 * The plugin consumes those seats structurally (see context.ts): the client
 * bundle's purity gate forbids value-importing another plugin's runtime, so
 * every interaction here is a cordis service method call, and the plugin
 * supplies its own React components.
 *
 * Both kinds are PAGE types (`patterns` omitted): they are opened by kind
 * (`tab.actions.openTab`), never by a `dsh-resource://` address, so the plugin
 * never competes with the product's own file viewers — a file inside the
 * session workspace keeps opening in whatever type already claims it, and the
 * tree hands its rows to the plugin's OWN preview tab (which reads through the
 * plugin's multi-root routes and therefore also reaches cross-drive shared
 * directories the host's workspace fence refuses).
 * @module dsh-codex-project/client/native-sidebar
 */
import { type ReactNode } from 'react';
import type { SpacesApi } from './api.ts';
import type { ClientRuntimeContext, NativeTabInfo, SessionListFace, SidebarRightTabDefinition, SidebarRightTabsService, SlotsService } from './context.ts';
/** The 项目文件夹 page type's kind (the value `openTab` names). */
export declare const PROJECT_KIND = "codex-project";
/** The 项目文件夹 implementation's identity, and the key its body registers under. */
export declare const PROJECT_ID = "@luoxunhao/dsh-codex-project";
/** The 文件预览 page type's kind. */
export declare const FILE_KIND = "codex-project-file";
/** The 文件预览 implementation's identity, and the key its body registers under. */
export declare const FILE_ID = "@luoxunhao/dsh-codex-project/file";
/**
 * The `params` a 文件预览 page carries: the absolute file it shows. The
 * plugin's own preview tab is a page without `multiple` (the pane keeps one per
 * kind per pane), so opening a second file NAVIGATES the open one instead of
 * stacking a tab — and `navigation.revision`, which ticks on every navigation
 * whether or not the params changed, is what tells the body to re-read.
 */
export interface FilePreviewParams {
    path: string;
}
/**
 * Read the file a 文件预览 page is aimed at out of a tab's `navigation.params`.
 *
 * The page deduplicates per pane, so a second 文件预览 open does not stack a
 * tab — it NAVIGATES the open one, and this is how the body and its chip title
 * learn which file they now show. Anything that is not a non-empty `path`
 * string (an absent params bag, a hand-written one) reads as "not aimed yet".
 * @param params - the tab's current `navigation.params`.
 * @returns the absolute file path, or undefined when the page was never aimed.
 */
export declare function previewPathOf(params: unknown): string | undefined;
/**
 * The 项目文件夹 page type's registry definition.
 *
 * Both definitions below are the SHARED `SidebarRightTabDefinition` face from
 * `context.ts` rather than a local restatement of it — one shape per contract.
 * The params they carry are likewise narrowed at runtime (`previewPathOf`)
 * instead of merged into the upstream `SidebarRightTabParamsMap`: the merge
 * would buy a compile-time check on `openTab(FILE_KIND, { params })` at the
 * cost of a type-only import of the carrier package, against this bundle's rule
 * that every native face is restated structurally so drift stays in one file.
 * Revisit if a second params-carrying kind ever shows up.
 */
export declare function projectDefinition(): SidebarRightTabDefinition;
/** The 文件预览 page type's registry definition (hidden from the guide). */
export declare function fileDefinition(): SidebarRightTabDefinition;
/**
 * What the native body receives: the framework's session standard props (the
 * active session id, injected by ui-session) plus the slot-level `useTabInfo`
 * hook (declared by ui-sidebar-right's seat for every registration), wrapped
 * with the plugin's own closed-over face.
 */
export interface NativeTabBodyProps {
    /** The session the tab lives in (framework-injected). */
    sessionId: string;
    /** The framework-bound reader of the tab record, its navigation and actions. */
    useTabInfo: () => NativeTabInfo;
    /** The observable session-list feed, so a late cwd re-renders the body. */
    sessions: SessionListFace | undefined;
    /** The plugin's own dirs API (closed over from `apply`). */
    api: SpacesApi;
    /** The client runtime context, for the `@` reference insert (closed over). */
    runtimeCtx: ClientRuntimeContext;
}
/**
 * The 项目文件夹 page body: the multi-root tree for the tab's session.
 * @param props - the framework session props plus the plugin's closed-over face.
 */
export declare function NativeProjectTab(props: NativeTabBodyProps): ReactNode;
/**
 * The 文件预览 page body: the plugin's own preview pane for the file the page
 * currently navigates to (`navigation.params.path`).
 *
 * The pane is keyed on the NAVIGATION, not just the path: `revision` ticks on
 * every navigation whether or not the params changed, so clicking the same file
 * a second time re-reads it (the tree is a live view of a directory the agent
 * is editing) instead of leaving a stale pane on screen. Remounting the whole
 * pane is the sanctioned shape here — see the CodeMirror rules in AGENTS.md §5:
 * the editor host must never be conditionally unmounted INSIDE the pane, but
 * the pane itself is safe to remount per navigation.
 * @param props - the framework session props plus the plugin's closed-over face.
 */
export declare function NativeFileTab(props: NativeTabBodyProps): ReactNode;
/** The 项目文件夹 chip title: the glyph plus the type's label. */
export declare function NativeProjectTitle(props: {
    useTabInfo: () => NativeTabInfo;
}): ReactNode;
/** The 文件预览 chip title: the current file's basename (falls back to the captured title). */
export declare function NativeFileTitle(props: {
    useTabInfo: () => NativeTabInfo;
}): ReactNode;
/** Everything the native registration needs from the plugin's client half. */
export interface NativeSidebarDeps {
    api: SpacesApi;
    /** The observable session-list feed the bodies read each cwd from. */
    sessions: SessionListFace | undefined;
    /** Close over the runtime ctx so `insertFileReference` keeps working. */
    runtimeCtx: ClientRuntimeContext;
}
/**
 * Register both page types into the native right Sidebar.
 *
 * The registration is the documented two-stage path: stage one declares the
 * types, stage two fills the keyed body and title seats. It runs once per
 * arrival of the services (see the `ctx.inject` call in `index.tsx`), and the
 * returned disposer takes every one of those contributions back — so a
 * re-arrival registers afresh rather than stacking.
 * @param deps - the dirs API, the session feed, and the runtime context.
 * @param services - the native services this path was mounted for.
 * @returns a disposer unregistering everything this call registered.
 */
export declare function registerNativeSidebar(deps: NativeSidebarDeps, services: {
    tabs: SidebarRightTabsService;
    slots: SlotsService;
}): () => void;
