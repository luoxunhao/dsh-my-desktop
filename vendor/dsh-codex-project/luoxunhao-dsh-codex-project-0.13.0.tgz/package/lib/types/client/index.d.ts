/**
 * dsh-codex-project client half: injects the 管理工作区 entry into the
 * native workspace 「…」 menu (DOM-level, self-healing) and mounts the
 * manage dialog it opens. It ALSO registers the 项目文件夹 tree — a
 * multi-root file tree of the project (main root + shared dirs, cross-drive)
 * with a per-file preview — as two page types of DSH's own right Sidebar
 * (`ctx.sidebarRightTabs` + the keyed `sidebar.right.pane.tab` seats; see
 * `native-sidebar.tsx`), which every web composition ships.
 *
 * The sidebar registration waits on those services through `ctx.inject` rather
 * than reading them once at apply time: whether THIS plugin applies before or
 * after `ui-sidebar-right` is up to the composition order, and a one-shot read
 * at apply would then see the carrier as absent and never come back. (Inside
 * `ui-sidebar-right` itself the registry is provided BEFORE its seats declare,
 * so it is the cross-plugin order that races, not the intra-plugin one.)
 *
 * The DOM-level injection follows the dsh-web-ui family precedent: the
 * workspace menu popup is React-managed native code with no extension
 * point, so the item is injected per popup-open and self-binds its click.
 *
 * Failure policy: DOM mounting problems are logged, never thrown — an
 * external plugin must not take the GUI down.
 */
import type { Context } from './context.ts';
/** Services required before mounting (provided by the client runtime). The
 *  sidebar carrier is OPTIONAL — cordis keeps a fiber pending while a required
 *  service is missing, so `sidebarRightTabs` never appears here; the plugin
 *  waits on it with `ctx.inject` instead. */
export declare const inject: string[];
/**
 * Client plugin body.
 * @param ctx - the client cordis context (workspaces).
 */
export declare function apply(ctx: Context): void;
