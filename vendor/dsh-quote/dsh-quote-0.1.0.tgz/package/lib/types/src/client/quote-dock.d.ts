/**
 * dsh-quote composer-dock entry: a selection-triggered 「添加到对话」popover.
 *
 * Registered into the session-scoped slot `conversation.composer.dock`, this
 * component is mounted for the whole active session. From it we attach
 * DOCUMENT-level `selectionchange` / `mouseup` listeners so that whenever the
 * user makes a text selection over a chat message row (`[data-chat-flow-key]`),
 * a small floating 「添加到对话」button appears anchored at the selection's end.
 * Clicking it silently queues the selected text for the session via the host
 * HTTP API; while the session has pending quotes a quiet, removable indicator
 * strip also renders below the composer.
 *
 * The component never crashes on a missing prop: DOM/API/slot problems degrade
 * to a logged no-op, never a throw, so a host that composes differently simply
 * shows no affordance.
 * @module dsh-quote/client/quote-dock
 */
import type { ReactElement } from 'react';
import type { ChatNodeStoreLike } from './slot-props.ts';
/** Selector over the chat snapshot we use to resolve a node key. */
type ChatNodeStore = ChatNodeStoreLike;
/** One resolved quote candidate from a selection over a chat row. */
export interface QuoteCandidate {
    /** The selected plain text (verbatim rendered text). */
    text: string;
    /** The row kind the selection came from (assistant / user / tool / …). */
    sourceKind?: string;
    /** The durable source message id, when the row resolves to a finalized message. */
    sourceMessageId?: string;
}
/** Where the floating button should sit: viewport coords of the selection end. */
export interface PopoverAnchor {
    x: number;
    y: number;
}
export interface QuoteDockProps {
    /** The current session id (ui-session merge; absent only when not composed). */
    sessionId?: string;
}
/**
 * Resolve a text selection over a chat row into a quote candidate: the selected
 * text plus, when resolvable, its row kind and finalized message id. Returns
 * undefined when the selection is empty or its anchor is not inside a chat flow
 * row (`[data-chat-flow-key]`).
 *
 * The selection is read from the live `window` selection (rendered text, verbatim
 * — per ADR-0001 we ingest what the user sees, not reconstructed markdown).
 * @param selectionText - the current window selection text.
 * @param anchorNode - the selection's anchor Node (an Element ancestor is walked).
 * @param nodes - the chat node store (`useChat((s) => s.nodes)`), optional.
 */
export declare function quoteFromSelection(selectionText: string, anchorNode: Node | null, nodes?: ChatNodeStore): QuoteCandidate | undefined;
/** The viewport rect at the END of the current selection (for anchoring the button). */
export declare function selectionAnchorRect(): PopoverAnchor | undefined;
/**
 * The composer.dock entry: hosts the selection listeners, the floating
 * 「添加到对话」button, and the pending-quote indicator strip for this session.
 *
 * Deliberately does NOT read `useChat`/other standard props: like sibling dock
 * entries it is behavior-only over the DOM, so a host that composes different
 * standard props still works. The quote carries the verbatim selected text and
 * its row kind; the durable messageId is a nice-to-have we forgo to stay
 * dependency-free.
 * @param props - session standard props; only `sessionId` is read.
 */
export declare function QuoteDock(props: QuoteDockProps): ReactElement | null;
export {};
