/**
 * dsh-quote client HTTP face over the host's loopback `/dsh-quote/api` routes.
 * Same-origin GUI; the host fences the routes to loopback. Every call throws
 * {@link QuoteApiError} on a non-2xx response.
 * @module dsh-quote/client/api
 */
/** One pending quote as the host stores it (mirror of the host PendingQuote). */
export interface PendingQuote {
    /** Stable id within its session. */
    readonly id: string;
    /** The selected plain text, verbatim. */
    readonly text: string;
    /** The durable source message id the selection came from, when resolvable. */
    readonly sourceMessageId?: string;
    /** The source row kind the selection came from (assistant / user / tool / …). */
    readonly sourceKind?: string;
}
/** A failed quotes call: HTTP status plus the host's message. */
export declare class QuoteApiError extends Error {
    readonly status: number;
    constructor(status: number, message: string);
}
/** The quotes API surface. */
export interface QuoteApi {
    /** List a session's pending quotes (in insertion order). */
    list(sessionId: string): Promise<readonly PendingQuote[]>;
    /** Add one pending quote to a session; resolves with the stored quote. */
    add(sessionId: string, quote: {
        text: string;
        sourceMessageId?: string;
        sourceKind?: string;
    }): Promise<PendingQuote>;
    /** Remove one pending quote by id; true when it existed. */
    remove(sessionId: string, quoteId: string): Promise<boolean>;
}
/** Create the quotes API client against one base path. */
export declare function createQuoteApi(base?: string): QuoteApi;
