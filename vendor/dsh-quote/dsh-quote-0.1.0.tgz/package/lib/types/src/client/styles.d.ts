/**
 * dsh-quote client styles: injected once as a `<style data-plugin-css="dsh-quote">`
 * tag. Colors ride the dsh `--dsw-*` tokens so the affordance follows the
 * active theme. Attribute-scoped so nothing leaks into the rest of the GUI.
 * @module dsh-quote/client/styles
 */
/** Inject the styles once; a repeated call is a no-op. */
export declare function injectStyles(): () => void;
