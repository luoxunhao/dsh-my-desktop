import type { Context } from '@deepseek-ai/cordis';
/** Plugin identity for cordis.yml rows. */
export declare const name = "dsh-quote";
/** Services required before mounting. */
export declare const inject: string[];
/**
 * Plugin body: serve the /dsh-quote/api routes and fold pending quotes on
 * each real user turn.
 * @param ctx - the host cordis context (webServer; agent events fire on ctx).
 */
export declare function apply(ctx: Context): void;
